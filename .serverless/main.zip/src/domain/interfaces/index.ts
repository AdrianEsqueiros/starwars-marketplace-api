export * from '../models/star-wars-marketplace.entity';
export * from './people.interface';
export * from './product.interface';
